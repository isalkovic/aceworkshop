########################
## SET UP ENVIRONMENT ##
########################
#
# Change this to directory on the R Server where data and logging will go
#
setwd("c:/student10/Analytics/RWork")
#
# Redirect stdout to file on R Server
#
sink("R_output.txt")