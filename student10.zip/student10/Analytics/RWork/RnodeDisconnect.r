################################################################
## Called when Integration Server running Rnode is stopped or ## 
## application is redeployed                                  ## 
## (example of what could be in a disconnect script)          ##
################################################################
#
# restore output to usual stdout
#
sink()
#